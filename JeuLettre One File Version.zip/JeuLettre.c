#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <conio.h>
#include <ctype.h>
#include <locale.h>

struct Joueur{
    char utilisateur[20];
    char motdepasse[20];
    int point;
};

/*Prototypes*/
void presentation();
void viderBuffer();
int lireChaine(char *chaine, int nombre);
long lireEntier();
long retour();

/*Prototypes relatives à Jouer*/
void choixMot(char * mot);
void masquerMot(char * mot, char * masqueMot);
void remplacerLettre(char lettre, char * mot, char * masqueMot, char *motFausse, int * chance);
int verifPseudo(char *pseudo, struct Joueur tabJoueur[100], int *position);
int verifPassword(char *password, struct Joueur tabJoueur[100], int *position);


/*Prototypes des fonctions principales*/
long jouer();
void MotDePasse(int nombre, char * password);
long menu();
long meilleursScores();
long instructions();
long quitter();



/*Fontions fondamentales*/
void viderBuffer(){
	int c = 0;
	while(c != '\n' && c != EOF){
		c = getchar();
	}
}

int lireChaine(char *chaine, int nombre){
	char *position = NULL;
	if(fgets(chaine, nombre, stdin) != NULL){
		if((position = strchr(chaine, '\n')) != NULL){
			*position = '\0';
		}
		else{
			viderBuffer();
		}
		return 1;
	}
	else{
		viderBuffer();
		return 0;
	}
}

long lireEntier(){
	char entier[3];
	if (lireChaine(entier, 3))
	{
		return strtol(entier, NULL, 10);
	}
	else{
		return 0;
	}
}

long retour(){
	long choix = 2;
	while(choix != 1 && choix != 0){
        printf("\nAppuyer sur : \n");
        printf("0- pour Retouner au Menu\n");
        printf("1- pour Continuer\n");
        printf("\nVotre Choix : ");
        choix = lireEntier();
	}
	return choix;
}

void MotDePasse(int nombre, char * password){
	char ch;
	for (int i = 0; i < nombre; ++i)
	{
		ch = getch();
		*(password + i) = ch;
		if (ch == '\r')
		{
		    *(password + i) = '\0';
			break;
		}
		ch = '*';
		printf("%c", ch);
	}
	printf("\n");
}

/*Fonctions relatives à Jouer*/
void choixMot(char * mot){
	FILE * fichier;
	int nbreAlea = 1;
	srand(time(NULL));
	nbreAlea = (rand() % 399) + 1;
	fichier = fopen("SaveM.bin", "r");
	if(fichier == NULL){
		printf("\nErreur d'ouverture l'hors du fichier\n");
		exit(1);
	}
	else{
		for (int i = 0; i < nbreAlea; ++i)
		{
			fgets(mot, 15, fichier);
		}
		*(mot + strlen(mot) - 1) = '\0';
	}
	fclose(fichier);
}

void masquerMot(char * mot, char * masqueMot){
	int i = 0;
	int nbreLettre = strlen(mot);
	for (i = 0; i < nbreLettre; ++i)
	{
		*(masqueMot + i) = '*';
	}
	*(masqueMot + i) = '\0';
}

void remplacerLettre(char lettre, char * mot, char * masqueMot, char *motFausse, int * chance){
	int verif = 0;
	for (int i = 0; i < strlen(mot); ++i)
	{
	    lettre = toupper(lettre);
	    if(lettre == *(masqueMot + i)){
            verif = 2;
	    }
		else if(lettre == *(mot + i))
		{
			*(masqueMot + i) = lettre;
			verif = 1;
		}
	}
	if (verif == 1){
		printf("Lettre trouvee !!!!\n");
		printf("Vous avez toujours %d chance(s)\n", *(chance));
	}
	else if(verif == 2){
        printf("Vous avez deja trouve cette lettre\n");
        printf("Vous avez toujours %d chance(s)\n", *(chance));
	}
	else{
		for (int i = 0; i < strlen(motFausse); ++i)
		{
			if (lettre == *(motFausse + i))
			{
				verif = 3;
			}
		}
		if (verif == 3)
		{
			printf("Vous avez deja fausse cette lettre\n");
			*(chance) = *(chance) - 2;
			if (*(chance) < 0)
			{
				*(chance) = 0;
			}
			printf("Il vous reste %d chance(s)\n", *(chance));
		}
		else{
			*(motFausse + strlen(motFausse)) = lettre;
			printf("Lettre erronee !!!!\n");
			*(chance) = *(chance) - 1;
			printf("Il vous reste %d chance(s)\n", *(chance));
		}
	}
}

int verifPseudo(char *pseudo, struct Joueur tabJoueur[100], int *position){
    int nbreJoueur = 0;
    int verif = 0;
    FILE * fichier1;
    FILE * fichier2;

    /*Lecture des Joueurs present*/
	fichier1 = fopen("SaveN.bin", "ab+");
	if (fichier1 == NULL)
	{
	    printf("\n\nErreur d'ouverture du fichier SaveN.bin\n");
		exit(1);
	};
	fscanf(fichier1, "%d", &nbreJoueur);
	fclose(fichier1);
	fichier2 = fopen("SaveJ.bin", "ab+");
	if(fichier2 == NULL){
        printf("\n\nErreur d'ouverture du fichier SaveJ.bin\n");
		exit(1);
	}
	fread(tabJoueur, sizeof(struct Joueur), nbreJoueur, fichier2);
	fclose(fichier2);

	for(int i = 0; i < nbreJoueur; i++){
        if(!strcmp(pseudo, tabJoueur[i].utilisateur)){
            verif = 1;
            *(position) = i;
            break;
        }
	}
	return verif;
}

int verifPassword(char *password, struct Joueur tabJoueur[100], int *position){
    int nbreJoueur = 0;
    int verif = 0;
    FILE * fichier1;
    FILE * fichier2;

    /*Lecture des Joueurs present*/
	fichier1 = fopen("SaveN.bin", "ab+");
	if (fichier1 == NULL)
	{
	    printf("\n\nErreur d'ouverture du fichier SaveN.bin\n");
		exit(1);
	};
	fscanf(fichier1, "%d", &nbreJoueur);
	fclose(fichier1);
	fichier2 = fopen("SaveJ.bin", "ab+");
	if(fichier2 == NULL){
        printf("\n\nErreur d'ouverture du fichier SaveJ.bin\n");
		exit(1);
	}
	fread(tabJoueur, sizeof(struct Joueur), nbreJoueur, fichier2);
	fclose(fichier2);

    if(!strcmp(password, tabJoueur[*(position)].motdepasse)){
        verif = 1;
    }
	return verif;
}

/*Fonctions Principales*/
void presentation(){
	printf("\nBienvenue dans le Jeu de Lettre\n");
	printf("Consulter l'instructions pour voir les regles du Jeu\n");
}

long menu(){
	long choix = 0;
	printf("\nMenu du Jeu\n");
	printf("\n1- Jouer\n");
	printf("2- Creer un compte\n");
	printf("3- Meilleurs Scores\n");
	printf("4- Instructions\n");
	printf("5- Quitter\n");
	printf("\nVotre Choix : ");
	choix = lireEntier();
	return choix;
}

long Jouer(){
    /*Declaration*/
    FILE * fichier2;
    FILE * fichier1;
    struct Joueur tabJoueur[100];
    int nbreJoueur = 0;
	char pseudo[20];
	char password[20];
	char mot[15], masqueMot[15], motFausse[15], lettre;
	long choix = 1;
	int motTrouve = 1;
	int chance;
	int *Pchance;
	int point = 0;
	int pseudoExiste = 0;
	int passwordExiste = 0;
	int positionJoueur = 0;
	int *PpositionJoueur;

	/*Initialisation*/
	Pchance = &chance;
	PpositionJoueur = &positionJoueur;

	/*Lecture des Joueurs present*/
	fichier1 = fopen("SaveN.bin", "ab+");
	if (fichier1 == NULL)
	{
	    printf("\n\nErreur d'ouverture du fichier SaveN.bin\n");
		exit(1);
	}
	fscanf(fichier1, "%d", &nbreJoueur);
	fclose(fichier1);
	fichier2 = fopen("SaveJ.bin", "ab+");
	if(fichier2 == NULL){
        printf("\n\nErreur d'ouverture du fichier SaveJ.bin\n");
		exit(1);
	}
	fread(tabJoueur, sizeof(struct Joueur), nbreJoueur, fichier2);
	fclose(fichier2);

	/*Debut du Jeu*/
	printf("\nConnectez-vous\n");
	printf("\nPseudo : ");
	lireChaine(pseudo, 20);

    /*Verification de l'existence du Pseudo*/
    pseudoExiste = verifPseudo(pseudo, tabJoueur, PpositionJoueur);
    if(pseudoExiste == 1){
        do{
            printf("Mot de passe : ");
            MotDePasse(20, password);
            passwordExiste = verifPassword(password, tabJoueur, PpositionJoueur);
        }while(passwordExiste != 1);
        point = tabJoueur[positionJoueur].point;
        printf("\nVous avez un score de %d point(s)\n", point);
        while(choix){
            choixMot(mot);
            masquerMot(mot, masqueMot);
            chance = 10;
            printf("\nVoici le mot masque : %s\nElle est compose de %ld lettres\n", masqueMot, strlen(mot));
            printf("\nVous avez %d chances pour le trouver\n", chance);
            while (motTrouve && chance){
                printf("\nEntrer une lettre : ");
                fflush(stdin);
                scanf("%c", &lettre);
                fflush(stdin);
                remplacerLettre(lettre, mot, masqueMot, motFausse, Pchance);
                printf("%s", motFausse);
                printf("\nLe nouveau mot est %s\n", masqueMot);
                motTrouve = strcmp(mot, masqueMot);
            }
            if (chance){
                printf("\n\nFelicitations vous avez trouve le mot \n\n");
                point += chance;
                printf("\nVous avez maintenant %d point(s)\n", point);
                tabJoueur[positionJoueur].point = point;
                /*Sauvegarde des Joueurs*/
                fichier2 = fopen("SaveJ.bin", "wb+");
                if (fichier2 == NULL)
                {
                    printf("\n\nErreur d'ouverture du fichier Save.bin\n");
                    exit(1);
                }
                fwrite(tabJoueur, sizeof(struct Joueur), nbreJoueur, fichier2);
                fclose(fichier2);
            }
            else{
                printf("\n\nVous avez perdu\n\n");
                printf("Le mot etait %s\n", mot);
            }
            motTrouve = 1;
            memset(motFausse, '\0', strlen(motFausse)-1);
            choix = retour();
        }
    }
    else{
            printf("\nVous n'avez pas de compte");
            printf("\nVeuiler creer un compte au Menu Principale\n");
            choix = 0;;
        }
	return 0;
}


/*Fonctions pour creer de nouveaux comptes dans la base de donnees*/
long creerCompte(){
	/*Declaration et initialisation*/
    struct Joueur tabJoueur[100];
    FILE * fichier1;
	FILE * fichier2;
    int nbreJoueur = 0;
    int nbreSave = 0;
	char pseudo[20];
	char password[20];
	char confirmPassword[20];
	int pseudoExiste = 0;
	int positionJoueur = 0;
	int *PpositionJoueur;
	int verificationPassword;
	int verificationPseudo = 0;
	int recommencerCreation = 0;
	long choix = 1;

	PpositionJoueur = &positionJoueur;;

	/*Lecture des donnees existantes*/
	fichier1 = fopen("SaveN.bin", "ab+");
	if (fichier1 == NULL)
	{
	    printf("\n\nErreur d'ouverture du fichier SaveN\n");
		exit(1);
	}
	fscanf(fichier1, "%d", &nbreJoueur);
	fclose(fichier1);
	fichier2 = fopen("SaveJ.bin", "ab+");
	if(fichier2 == NULL){
        printf("\n\nErreur d'ouverture du fichier SaveJ.bin\n");
		exit(1);
	}
	fread(tabJoueur, sizeof(struct Joueur), nbreJoueur, fichier2);
	fclose(fichier2);

	/*Creation du compte*/
	while (choix == 1){
		printf("\nCreation du Compte\n");

		/*Verifier si le pseudo existe deja dans la base de donnees*/
		printf("\nEntrer votre Pseudo : ");
		lireChaine(pseudo, 20);
		verificationPseudo = verifPseudo(pseudo, tabJoueur, PpositionJoueur);
		if(verificationPseudo == 1){
			printf("\nUn compte porte deja ce nom.\nVeuillez choisir un autre Pseudo\n");
			recommencerCreation = 1;
		}
		if (recommencerCreation == 0)
		{
			/*Continuer si le pseudo n'existe pas*/
			printf("Entrer votre Mot de passe : ");
			MotDePasse(20, password);
			printf("Confirmer votre Mot de Passe : ");
			MotDePasse(20, confirmPassword);
			verificationPassword = strcmp(password, confirmPassword);
			if (verificationPassword == 0){
				printf("\n%s, vous avez ete enregistre avec succes\n", pseudo);

				/*Enregistrement des joueurs dans la tabJoueur*/
				strcpy(tabJoueur[nbreJoueur].utilisateur, pseudo);
				strcpy(tabJoueur[nbreJoueur].motdepasse, password);
				tabJoueur[nbreJoueur].point = 0;
				nbreJoueur++;
				nbreSave++;

				/*Sauvegarde des Joueurs*/
				fichier2 = fopen("SaveJ.bin", "wb+");
				if (fichier2 == NULL)
				{
					printf("\n\nErreur d'ouverture du fichier SaveJ.bin\n");
					exit(1);
				}
				fwrite(tabJoueur, sizeof(struct Joueur), nbreJoueur, fichier2);
				fclose(fichier2);

				/*Sauvegarde du nombre de Joueur*/
				fichier1 = fopen("SaveN.bin", "wb+");
				if (fichier1 == NULL)
				{
					printf("\n\nErreur d'ouverture du fichier SaveN.bin\n");
				}
				fprintf(fichier1, "%d", nbreJoueur);
				fclose(fichier1);
			}
			else {
				printf("\nMot de passe non confirme\n");
			}
			choix = retour();
		}
		else{
			choix = 0;
		}
	}
	printf("\n%d sauvegarde(s) enregistre(s)\n", nbreSave);
	return choix;
}

/*Fonctions classant des meilleurs joueurs*/
long meilleursScores(){
	printf("\nMeilleurs Scores\n");

	/*Declaration et Initialisation*/
	struct Joueur tabJoueur[100];
	struct Joueur temp;
    FILE * fichier1;
	FILE * fichier2;
    int nbreJoueur = 0;
    int max = 0;

	/*Lecture des donnees existantes*/
	fichier1 = fopen("SaveN.bin", "ab+");
	if (fichier1 == NULL)
	{
	    printf("\n\nErreur d'ouverture du fichier SaveN.bin\n");
		exit(1);
	}
	fscanf(fichier1, "%d", &nbreJoueur);
	fclose(fichier1);
	fichier2 = fopen("SaveJ.bin", "ab+");
	if(fichier2 == NULL){
        printf("\n\nErreur d'ouverture du fichier SaveJ.bin\n");
		exit(1);
	}
	fread(tabJoueur, sizeof(struct Joueur), nbreJoueur, fichier2);
	fclose(fichier2);
    if(nbreJoueur == 0){
        printf("\nAucune donnee enregistree pour l'instant\n ");
    }
	/*Tri de tabJoueur par ordre decroissant*/
	for (int i = 0; i < nbreJoueur - 1; ++i)
	{
		max = i;
		for (int u = i+1; u < nbreJoueur; ++u)
		{
			if(tabJoueur[max].point < tabJoueur[u].point){
				max = u;
			}
		}
		if (max != i)
		{
			strcpy(temp.utilisateur, tabJoueur[i].utilisateur);
			strcpy(temp.motdepasse, tabJoueur[i].motdepasse);
			temp.point = tabJoueur[i].point;
			strcpy(tabJoueur[i].utilisateur, tabJoueur[max].utilisateur);
			strcpy(tabJoueur[i].motdepasse, tabJoueur[max].motdepasse);
			tabJoueur[i].point = tabJoueur[max].point;
			strcpy(tabJoueur[max].utilisateur, temp.utilisateur);
			strcpy(tabJoueur[max].utilisateur, temp.motdepasse);
			tabJoueur[max].point = temp.point;
		}
	}

	/*Enregistrement du nouveau tableau*/
	fichier2 = fopen("SaveJ.bin", "wb+");
	if(fichier2 == NULL){
        printf("\n\nErreur d'ouverture du fichier SaveJ.bin\n");
		exit(1);
	}
	fwrite(tabJoueur, sizeof(struct Joueur), nbreJoueur, fichier2);
	fclose(fichier2);

	/*Affichage des 5 premiers meilleurs scores*/
	if (nbreJoueur >= 5)
	{
		for (int i = 0; i < 5; ++i)
		{
			printf("\n%d-\t%3d\t%s", i+1, tabJoueur[i].point, tabJoueur[i].utilisateur);
		}
		printf("\n");
	}
	else{
		for (int i = 0; i < nbreJoueur; ++i)
		{
			printf("\n%d-\t%3d\t%s", i+1, tabJoueur[i].point, tabJoueur[i].utilisateur);
		}
		printf("\n");
	}
	return 0;
}

/*Fonctions presentant le jeu*/
long instructions(){
	int choix;
	printf("\nInstructions\n");
	printf("\n\nCe jeu est connu sous le nom du Jeu du Pendu");
	printf("\n\n\tDescription du Jeu\n");
	printf("\nLe programme choisira un mot et votre objectif");
	printf("\nsera de le deviner le plus rapidement possible");
	printf("\n\n\tEtapes pour Jouer\n");
	printf("\nPour jouer a ce jeu, vous devez imperativement");
	printf("\navoir creer un compte");
	printf("\n\n\tCreation d'un compte\n");
	printf("\nPour creer un compte vous devez aller dans la ");
	printf("\nrubrique 2 du Menu du Jeu et suivre les instructions");
	printf("\nNB : Le Pseudo et le Mot de passe doivent être ");
	printf("\ninferieur a 20 caracteres");
	printf("\n\n\tJouer\n");
	printf("\nPour jouer, aller dans la rubrique 1 du Menu de ");
	printf("\nJeu et entrer vos donnees.");
	printf("\nVous debutez le jeu avec 0 point et vous avez 10 ");
	printf("\nchances pour deviner le mot choisi par le programme.");
	printf("\nLe nombre de chances qui reste sera considere ");
	printf("\ncomme le point gagne l'hors de cette partie.");
	printf("\nAu debut de chaque partie, le nombre de points totals ");
	printf("\ngagnes vous sera affiche.");
	printf("\nSi vous faussez une lettre deja faussee, le nombre");
	printf("\nde chances diminuera de deux et si vous rentrez une ");
	printf("\nlettre deja trouve, aucune chance ne sera enlevee");
	printf("\n\n\tMeilleurs Scores\n");
	printf("\nRubrique 3 du Jeu.");
	printf("\nAffiche les 5 personnes ayant gagnes le plus de points");
	printf("\n\nNB :   1- En Saisissant votre mot de passe, vous ne ");
	printf("\n          pouvez plus l'effacer. Soyer donc attentif a ");
	printf("\n          ce que vous saisissez !!!!!");
	printf("\n       2- L'Hors de la question du choix du Retour au ");
	printf("\n          Menu Principal ou non, si vous entrer une lettre");
	printf("\n          de l'alphabet, elle sera consideree comme 0.\n");
	printf("\nMerci\n");
	printf("\nAuteur : Marco Person");
	printf("\nSociete : Ispace");
	printf("\nMail : Marcoperson2000@gmail.com\n");
	choix = retour();
	return choix;
}

/*Fonctions se chargeant de la fermeture du programme*/
long quitter(){
	printf("\nFin Du Jeu\nA la prochaine\n");
	return 1;
}

//Programme principale
int main(int argc, char const *argv[])
{
    setlocale(LC_CTYPE,"");
	long choixMenu = 0;
	long choixRetour = 0;
	presentation();
	while(choixRetour == 0){
		choixMenu = menu();
		switch (choixMenu){
			case 1:
				choixRetour = Jouer();
				break;
			case 2:
				choixRetour = creerCompte();
				break;
			case 3:
				choixRetour = meilleursScores();
				break;
			case 4:
				choixRetour = instructions();
				break;
			case 5:
				choixRetour = quitter();
				break;
			default:
				printf("\nEntrer une valeur compris entre 1 et 5\n");
				break;
		}
	}
	return 0;
}
