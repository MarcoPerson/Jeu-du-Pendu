Pour Jouer/ To play the Game :

--------Pour les Fran�ais-------------
1- D�compressez l'archive JeuLettre V1.2.zip
2- Double cliquer sur JeuLettre
3- Profitez du Jeu

--------For English People------------
1- Unzip the Zip file JeuLettre V1.2.zip
2- Double click on JeuLettre
3- Enjoy the game


--------D�veloppeur/Developper--------
Auteur : Marco Person
Societe : Ispace
Mail : Marcoperon2000@gmail.com